package com.farmacia;

import javax.swing.*;
import java.awt.event.ActionEvent;

public class MenuPrincipal {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Inventario Farmacia");
        frame.setSize(300, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        JButton btnRegistrar = new JButton("Registrar Producto");
        btnRegistrar.setBounds(50, 30, 200, 40);
        btnRegistrar.addActionListener((ActionEvent e) -> {
            new PantallaRegistrarProducto();
        });

        JButton btnSalir = new JButton("Salir");
        btnSalir.setBounds(50, 90, 200, 40);
        btnSalir.addActionListener(e -> System.exit(0));

        frame.add(btnRegistrar);
        frame.add(btnSalir);
        frame.setVisible(true);
    }
}